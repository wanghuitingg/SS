if (!String.prototype.ltrim) {
	//ltrim ȥ���ַ�����ߵĿո�
	((String.prototype.ltrim = function () {return this.replace(arguments.callee.re,"");}).re = new RegExp()).compile("^\\s+","gi");
} else {
	throw new Error("String.prototype.ltrim�����Ѵ���!");
}
if (!String.prototype.rtrim) {
	//rtrim ȥ���ַ����ұߵĿո�
	((String.prototype.rtrim = function () {return this.replace(arguments.callee.re,"");}).re = new RegExp()).compile("\\s+$","gi");
} else {
	throw new Error("String.prototype.rtrim�����Ѵ���!");
}
if (!String.prototype.ftrim) {
	//frim ȥ���ַ��������еĿո�
	((String.prototype.ftrim = function () {return this.replace(arguments.callee.re,"");}).re = new RegExp()).compile("\\s","gi");
} else {
	throw new Error("String.prototype.ftrim�����Ѵ���!");
}
if (!String.prototype.trim) {
	//trim ȥ���ַ������ߵĿո�
	String.prototype.trim = function () {return this.ltrim().rtrim();};
} else {
	throw new Error("String.prototype.trim�����Ѵ���!");
}
if (!String.prototype.repeat) {
	//repeat �ظ�һ���ַ�����num����ָ���ظ�����
	String.prototype.repeat = function (num) {return (new Array(num+1)).join(this);};
} else {
	throw new Error("String.prototype.repeat�����Ѵ���!");
}
if (!String.prototype.isEmail) {
	//isEmail �ж��ַ����Ƿ�����Ч�������ַ������true��ʾ��ȷ
	((String.prototype.isEmail = function () {return arguments.callee.re.test(this);}).re=new RegExp()).compile("^\\w{1,15}(?:@(?!-))(?:(?:[a-z0-9-]*)(?:[a-z0-9](?!-))(?:\\.(?!-)))+[a-z]{2,4}$","i");
} else {
	throw new Error("String.prototype.isEmail�����Ѵ���!");
}
if (!String.prototype.reverse) {
	//reverse ���ַ�����ת
	String.prototype.reverse = function () {return this.split("").reverse().join("");};
} else {
	throw new Error("String.prototype.reverse�����Ѵ���!");
}
if (!String.prototype.nl2br) {
	//nl2br ���ַ����еĻ��з��滻��<br />
	((String.prototype.nl2br = function () {return this.replace(arguments.callee.re,"<br />");}).re=new RegExp()).compile("\\r\\n|\\n\\r|\\n|\\r","g");
} else {
	throw new Error("String.prototype.nl2br�����Ѵ���!");
}
if (!String.prototype.encodeHTML) {
	//encodeHTML ���ַ����е�HTML�����ַ��滻��ʵ������
	String.prototype.encodeHTML = function () {return this.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quote;");};
} else {
	throw new Error("String.prototype.encodeHTML�����Ѵ���!");
}
if (typeof window.XT != "undefined" ) {
	throw new Error("�����ռ�XT�Ѵ���!");
}
function XT() {//�����ռ俪ʼ
	return document.getElementById(arguments[0]);
	//Event��ʼ
	function addEvent(obj,evtype,fn,useCapture) {
		if (obj.addEventListener) {
			obj.addEventListener(evtype,fn,!!useCapture);
		} else {
			if (!fn.__EventID) {fn.__EventID = addEvent.__EventHandlesCounter++;}
			if (!obj.__EventHandles) {obj.__EventHandles={};}
			if (!obj.__EventHandles[evtype]) {
				obj.__EventHandles[evtype]=[];
				if (obj["on"+evtype]) {
					(obj.__EventHandles[evtype][0]=obj["on"+evtype]).__EventID=0;
				}
				obj["on"+evtype]=execEventHandles;
			}
			obj.__EventHandles[evtype][fn.__EventID]=fn;
		}
	}
	addEvent.__EventHandlesCounter=1;
	function execEventHandles(evt) {
		if (!this.__EventHandles) {return true;}
		evt =fixEvent(evt || window.event);
		var fns = this.__EventHandles[evt.type];
		for (var i=0;i< fns.length;i++) {
			if (fns[i] instanceof Function) {fns[i].call(this,evt);}
		}
	};
	function fixEvent(evt) {
		if (!evt.target) {
			evt.target = evt.srcElement;
			evt.preventDefault =preventDefault;
			evt.layerX = evt.offsetX;
			evt.layerY = evt.offsetY;
			if (evt.type == "mouseover") {
				evt.relatedTarget = evt.fromElement;
			} else if (evt.type=="mouseout") {
				evt.relatedTarget = evt.toElement;
			}
			evt.stopPropagation =stopPropagation;
		}
		return evt;
	}
	function preventDefault() {
		this.returnValue = false;
	};
	function stopPropagation() {
		this.cancelBubble = true;
	};
	function delEvent(obj,evtype,fn,useCapture) {
		if (obj.removeEventListener) {
			obj.removeEventListener(evtype,fn,!!useCapture);
		} else {
			if (obj.__EventHandles) {
				var fns = obj.__EventHandles[evtype];
				if (fns) {
					delete fns[fn.__EventID];
				}
			}
		}
	};
	window.XT.addEvent = addEvent;
	window.XT.delEvent = delEvent;
	//Event����
	
	//Drag��ʼ
	function Drag(obj,handle,cn) {
		handle.div = obj; 
		addEvent(handle,"mousedown", Drag.drag);
		handle.movingClassName = cn;
	}
	Drag.curObj = {};
	Drag.drag =  function (evt) {
		if (document.selection && document.selection.empty) {document.selection.empty();}  //IE
		else if (window.getSelection) {window.getSelection().removeAllRanges(); }//���
		this.div.className = this.movingClassName ;
		addEvent(document,"mouseup", Drag.drop);
		Drag.curObj = this.div;
		addEvent(document,"mousemove" ,Drag.moveDiv);
		this.div.offset = {
			x:evt.layerX,
			y:evt.layerY
		};
	};
	Drag.drop = function drop(evt) {
		delEvent(document,"mouseup",Drag.drop);
		delEvent(document,"mousemove",Drag.moveDiv);
		Drag.curObj.className = "";
	};
	Drag.moveDiv = function (evt) {
		Drag.curObj.style.left = evt.clientX-Drag.curObj.offset.x+"px";
		Drag.curObj.style.top = evt.clientY-Drag.curObj.offset.y+"px";
	};
	window.XT.Drag = Drag;
	//Drag����
	
	
};//�����ռ����
